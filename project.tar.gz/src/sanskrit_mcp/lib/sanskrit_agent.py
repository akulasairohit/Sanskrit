"""Sanskrit Agent - placeholder module."""

from .types import Agent


class SanskritAgent(Agent):
    """Sanskrit-capable agent (extends base Agent class)."""

    pass
